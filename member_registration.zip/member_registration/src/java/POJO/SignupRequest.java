
package POJO;

/**
 * @Class SignupRequest.java
 * @version 
 * @date 04/09/2016
 * @author Minju Park (13839910)
 */
public class SignupRequest {
    
    private String username;
    private String password;
    private String email;
    private String introduction;
    private String reason;
    private String requestDate;

    public SignupRequest(String username, String password, String email, String introduction, String reason, String requestDate) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.introduction = introduction;
        this.reason = reason;
        this.requestDate = requestDate;
        
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getIntroduction() {
        return introduction;
    }

    public String getReason() {
        return reason;
    }
    
    
            
}
