<?php	
	if(isset($_POST["username"]) && isset($_POST["password"]))
	{
		$username = $_POST["username"];
		$password = $_POST["password"];
		
		require_once("settings.php");
			
			$conn = @mysqli_connect($host, $user, $pswd, $dbnm);
		
			if (!$conn) {
				echo "<p>Database connection failure</p>";
			} else {
				$query = "SELECT * FROM (database name)
						  WHERE username = $username
						  AND password = $password";
				
								
				$result = mysqli_query($conn, $query);
				
				if($result) {
					/*
						successful login
						redirect to user home page
					*/
				} else {
					/*
						unsuccessful login
						notify user
					*/
				}
				mysqli_close($conn);
			}
	}else{
		echo "An error occurred, please try again." ;
	}

?>