<?php
	$host = "";
	$user = "";
	$pswd = "";
	$dbnm = "";
	$tabl = "";
?>