/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;

/**
 *
 * @author Keenen Leyson - 13828049
 */
@Stateless
public class DatabaseBean implements DatabaseBeanRemote, DatabaseBeanLocal{
    private static String dbURL = "jdbc:derby://localhost:1527/UpStageUserDB";
    private static String userTable = "UpStageUsersTable";
    private static String usernameDB = "keenen";
    private static String passwordDB = "keenen";
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

        
    public boolean addUser(String username, String password, String email, boolean approved) {
        boolean inserted = false;
        approved = false;
        try {
            Connection con = DriverManager.getConnection(dbURL, usernameDB, passwordDB);
            
            PreparedStatement ps = con.prepareStatement("INSERT INTO "+userTable+" (username, password, email, approved) VALUES (?,?,?,?)");
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, email);
            ps.setBoolean(4, approved);
            
            ps.executeUpdate();
            con.commit();
            con.close(); 
            inserted = false;
        } catch (SQLException ex) {
             Logger.getLogger(DatabaseBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(inserted == true){
            System.out.println("Successfully Added User");            
        }else{
            System.out.println("Error. Try Again.");
        }
        return inserted;
    }
    
    public boolean approve(String username)
    {
        boolean accepted = false;
        try {
            Connection con = DriverManager.getConnection(dbURL, usernameDB, passwordDB);
            
            PreparedStatement ps = con.prepareStatement("UPDATE * FROM "+userTable+
                                                        " WHERE username = ? "
                                                        + "AND NOT approved"
                                                        + "SET approved = CASE approved WHEN 0 THEN 1");
            ps.setString(1, username);
            
            ResultSet rs = ps.executeQuery();
            rs.next();            
            
            con.commit();
            con.close();
            
        } catch (SQLException ex) {
             Logger.getLogger(DatabaseBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        return accepted;
    }
    
    
    public boolean userExists(String username) {
        boolean exists = false;
        
        try {
            Connection conn = DriverManager.getConnection(dbURL, usernameDB, passwordDB);
            PreparedStatement ps = conn.prepareStatement("SELECT username FROM managers WHERE username LIKE ?");
            ps.setString(1, username);
            
            ResultSet rs = ps.executeQuery();
            
            exists = rs.next();
            conn.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return exists;
    }

    public boolean checkPassword(String username, String password) {
        boolean match = false;
        
        try {
            Connection conn = DriverManager.getConnection(dbURL, usernameDB, passwordDB);
            PreparedStatement ps = conn.prepareStatement("SELECT password FROM managers WHERE username LIKE ?");
            ps.setString(1, username);
            
            ResultSet rs = ps.executeQuery();
            rs.next();
            
            match = rs.getString("password").equals(password);
            conn.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseBean.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return match;
    }
    
}
