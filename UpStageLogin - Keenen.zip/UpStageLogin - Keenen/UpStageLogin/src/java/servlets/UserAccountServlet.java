/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import beans.UserSession;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Keenen Leyson - 13828049
 */
public class UserAccountServlet extends HttpServlet{
    @EJB database.DatabaseBeanLocal localDB;
    
    
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        HttpSession session = request.getSession(true);
        
        if (action != null && action.equals("logout")){
            session.invalidate();
            RequestDispatcher d = getServletContext().getRequestDispatcher("/home.jsp");
            d.forward(request, response);
        }
        else {
            UserSession us = (UserSession) session.getAttribute("loginState");
            String name = request.getParameter("username");
            String password = request.getParameter("password");

            if(!us.isLoggedIn() && name == null) {
                request.setAttribute("message", "");
                RequestDispatcher d = getServletContext().getRequestDispatcher("/login.jsp");
                d.forward(request, response);
            }        
            else if (name != null){
                if(localDB.userExists(name)) {
                    us = new UserSession();
                    if (localDB.checkPassword(name, password)) {
                        us.setLoggedIn(true);
                        us.setUsername(name);
                        session.setAttribute("loginState", us);
                        RequestDispatcher d = getServletContext().getRequestDispatcher("/userHome.jsp");
                        d.forward(request, response); 
                    }
                    else {
                        us.setUsername(name);
                        session.setAttribute("loginState", us);
                        request.setAttribute("message", "Password Incorrect");
                        RequestDispatcher d = getServletContext().getRequestDispatcher("/login.jsp");
                        d.forward(request, response);  
                    }               
                }   
                else {
                    request.setAttribute("message", "Username Does not exist.");
                    RequestDispatcher d = getServletContext().getRequestDispatcher("/login.jsp");
                    d.forward(request, response);  
                }
            }
            else if (us.isLoggedIn()){
                RequestDispatcher d = getServletContext().getRequestDispatcher("/userHome.jsp");
                d.forward(request, response);  
            }
        }
    }
}
